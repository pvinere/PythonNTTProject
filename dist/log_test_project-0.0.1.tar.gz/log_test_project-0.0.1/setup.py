import setuptools

setuptools.setup(
    name='log_test_project',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='Sebastian Pricea, Vinereanu Puiu-Andrei, Eduard Pricopi',
    author_email='',
    description=''
)